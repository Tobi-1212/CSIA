//
//  PrototypeApp.swift
//  Prototype
//
//  Created by Tobias Roiser on 02.05.2024.
//

import SwiftUI

@main
struct PrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
