import SwiftUI
import PhotosUI

struct Story: Identifiable {
    let id = UUID()
    let titleText: String
    let titleImage: Image
    let captions: [String] = []
    let images: [Image] = []
}

struct AddView: View {
    @State private var captionText = ""
    @State private var showView = "Add"
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var selectedImage: Image?
    @State private var stories: [Story] = []
    @State private var selectedStory: Story?
    
    var body: some View {
        if showView == "Home" {
            HomeView()
        } else if showView == "Settings" {
            SettingsView()
        } else if showView == "Edit", selectedStory != nil {
            EditView(story: $selectedStory)
        } else {
            VStack {
                HStack {
                    Button(action: {
                        showView = "Home"
                    }) {
                        Label("Home", systemImage: "house")
                    }
                    .padding()
                    Button(action: {
                        showView = "Settings"
                    }) {
                        Label("Settings", systemImage: "gear")
                    }
                    .padding()
                }

                Text("Create new story")
                    .font(.title)
                    .padding(.bottom, 20)
                
                PhotosPicker("Select Cover Image",
                             selection: $selectedPhoto,
                             matching: .images)
                    .padding(.bottom, 20)

                selectedImage?
                    .resizable()
                    .scaledToFit()

                TextField("Add story title...", text: $captionText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(maxWidth: 300)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)

                Button(action: {
                    if selectedImage != nil || !captionText.isEmpty {
                        let newStory = Story(titleText: captionText, titleImage: selectedImage ?? Image(systemName: "photo"))
                        selectedStory = newStory
                        stories.append(newStory)
                        captionText = ""
                        selectedImage = nil
                        showView = "Edit"
                    }
                }) {
                    Label("Add Story", systemImage: "plus.square")
                }
            }
            .task(id: selectedPhoto) {
                if let data = try? await selectedPhoto?.loadTransferable(type: Data.self),
                   let uiImage = UIImage(data: data) {
                    selectedImage = Image(uiImage: uiImage)
                }
            }
            .padding()
        }
    }
}

#Preview {
    AddView()
}
