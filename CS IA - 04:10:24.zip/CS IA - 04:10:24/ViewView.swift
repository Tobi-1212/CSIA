// ViewView.swift
// Prototype
//
// Created by Tobias Roiser on 02.05.2024.
//

import SwiftUI
import PhotosUI

struct ViewView: View {
    @State private var showView = "View"
    
    var body: some View {
        if showView == "Home" {
            HomeView()
        } else {
            VStack {
                Button(action: {
                    showView = "Home"
                }) {
                    Label("Home", systemImage: "house")
                }
                .padding()
                
                Text("View Stories")
                    .font(.title)
                    .padding(.bottom, 20)
                
                List {
                    Button(action: {
                        showView = "Home"
                    }) {
                        Label("Story 1", systemImage: "book.closed")
                    }
                }
            }
            .padding()
        }
    }
}

#Preview {
    ViewView()
}
