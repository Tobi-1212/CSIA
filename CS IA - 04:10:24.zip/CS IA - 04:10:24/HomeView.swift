//
//  HomeView.swift
//  Prototype
//
//  Created by Tobias Roiser on 06.06.2024.

import SwiftUI

struct HomeView: View {
    @State private var showView = "Home"
    var body: some View {
        if showView == "Add"{
            AddView()
        } else if showView == "View"{
            ViewView()
        } else if showView == "Settings"{
            SettingsView()
        } else {
            VStack{
                Button(action: {
                    showView = "Settings"
                }) {
                    Label("Settings", systemImage: "gear")
                }
                Text("Welcome to the Home Page!")
                    .font(.largeTitle)
                    .padding()
                HStack{
                    Button(action: {
                        showView = "Add"
                    }) {
                        Label("New Story", systemImage: "plus.app")
                    }
                    .padding()
                    Button(action: {
                        showView = "View"
                    }) {
                        Label("View Stories", systemImage: "eye")
                    }
                    .padding()
                }
            }
        }
    }
}


#Preview {
    HomeView()
}
