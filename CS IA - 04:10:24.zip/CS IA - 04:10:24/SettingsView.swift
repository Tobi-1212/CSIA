import SwiftUI

struct SettingsView: View {
    @State private var showView = "Settings"
    @AppStorage("isDarkMode") private var isDarkMode = false
    @AppStorage("volume") private var volume: Double = 0.5
    
    enum Language: String, CaseIterable, Identifiable {
        case english, german, french
        var id: Self { self }
    }

    @AppStorage("selectedLanguage") private var selectedLanguage: Language = .english
    
    var body: some View {
        Group {
            if showView == "Home" {
                HomeView()
            } else {
                VStack {
                    Button(action: {
                        showView = "Home"
                    }) {
                        Label("Home", systemImage: "house")
                    }
                    .padding()
                    
                    Text("Settings")
                        .font(.title)
                        .padding(.bottom, 20)

                    Toggle("Dark Mode", isOn: $isDarkMode)
                        .padding()
                    
                    HStack {
                        Text("Volume: \(Int(volume * 100))%")
                            .padding(.top, 5)
                        Slider(value: $volume, in: 0...1)
                            .padding(.horizontal)
                    }
                    HStack{
                        Text("Language")
                        Picker("Language", selection: $selectedLanguage) {
                            Text("English").tag(Language.english)
                            Text("Deutsch").tag(Language.german)
                            Text("Français").tag(Language.french)
                        }
                    }
                    
                    Spacer()
                }.frame(maxWidth: 500)
                .padding()
            }
        }
        .preferredColorScheme(isDarkMode ? .dark : .light)
        .animation(.easeInOut, value: showView)
    }
}

#Preview {
    SettingsView()
}
