//
//  EditView.swift
//  Prototype
//
//  Created by Tobias Roiser on 19.09.2024.
//

import SwiftUI
import AVFoundation

struct EditView: View {
    
    @Binding var story: Story?
    
    @State private var showView = "Edit"
    @State private var synthesizer = AVSpeechSynthesizer()
    
    var body: some View {
        if showView == "Home"{
            HomeView()
        } else if showView == "View"{
            ViewView()
        } else if showView == "Settings"{
            SettingsView()
        } else {
            VStack{
                HStack{
                    Button(action: {
                        showView = "Home"
                    }) {
                        Label("Home", systemImage: "house")
                    }
                }

                if let story = story {
                    VStack {
                        story.titleImage
                            .resizable()
                            .scaledToFit()
                            .frame(height: 200)
                            .padding()
                    
                        HStack{
                            Text(story.titleText)
                                .font(.title)
                                .padding(.bottom, 20)
                            
                            Button(action: {
                                let utterance = AVSpeechUtterance(string: story.titleText)
                                let voice = AVSpeechSynthesisVoice(language: "en-GB")
                                utterance.voice = voice
                                synthesizer.speak(utterance)
                            }){
                                Label("Speak", systemImage: "speaker.3")
                            }
                        }
                    }
                } else {
                    Text("No story selected")
                        .font(.title)
                        .padding()
                }
            }
        }
    }
}

#Preview {
    EditView(story: .constant(Story(titleText: "Not a Story", titleImage: Image(systemName: "book.pages"))))
}
